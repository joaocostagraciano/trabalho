<script setup>
import HelloWorld from './components/HelloWorld.vue'
import TheWelcome from './components/TheWelcome.vue'
</script>

<template>

<label for="nome">Nome:</label>
<input type="text" id="nome" name="nome" required>

<label for="email">E-mail:</label>
<input type="email" id="email" name="email" required>

<label for="senha">Senha:</label>
<input type="password" id="senha" name="senha" required>

<label for="confirmar-senha">Confirmação de senha:</label>
<input type="password" id="confirmar-senha" name="confirmar-senha" required>

<label for="data-nascimento">Data de nascimento:</label>
<input type="date" id="data-nascimento" name="data-nascimento" required>

<label for="endereco">Endereço:</label>
<input type="text" id="endereco" name="endereco" required>

<label for="cidade">Cidade:</label>
<input type="text" id="cidade" name="cidade" required>

<label for="estado">Estado:</label>
<select id="estado" name="estado" required>
  <option value="">Selecione</option>
  <option value="AC">Acre</option>
  <option value="AL">Alagoas</option>
  <option value="AP">Amapá</option>
  <option value="AM">Amazonas</option>
  <option value="BA">Bahia</option>
  <option value="CE">Ceará</option>
  <option value="DF">Distrito Federal</option>
  <option value="ES">Espírito Santo</option>
  <option value="GO">Goiás</option>
  <option value="MA">Maranhão</option>
  <option value="MT">Mato Grosso</option>
  <option value="MS">Mato Grosso do Sul</option>
  <option value="MG">Minas Gerais</option>
  <option value="PA">Pará</option>
  <option value="PB">Paraíba</option>
  <option value="PR">Paraná</option>
  <option value="PE">Pernambuco</option>
  <option value="PI">Piauí</option>
  <option value="RJ">Rio de Janeiro</option>
  <option value="RN">Rio Grande do Norte</option>
  <option value="RS">Rio Grande do Sul</option>
  <option value="RO">Rondônia</option>
  <option value="RR">Roraima</option>
  <option value="SC">Santa Catarina</option>
  <option value="SP">São Paulo</option>
  <option value="SE">Sergipe</option>
  <option value="TO">Tocantins</option>
</select>

<label for="hobbies">Hobbies:</label>
<textarea id="hobbies" name="hobbies"></textarea>

<label for="linguagens">Linguagens de programação:</label>
<input type="text" id="linguagens" name="linguagens">

<label for="biografia">Biografia:</label>
<textarea id="biografia" name="biografia"></textarea>


    

  <div>
    <form @submit.prevent="submitForm">
      <button type="submit">Salvar</button>
    </form>
    <div v-if="showUserData">
      <h2>Dados do usuário:</h2>
      <p>Nome: {{ userData.nome }}</p>
      <p>E-mail: {{ userData.email }}</p>
      <p>Data de nascimento: {{ userData.dataNascimento }}</p>
      <p>Endereço: {{ userData.endereco }}, {{ userData.cidade }}, {{ userData.estado }}</p>
      <p>Hobbies: {{ userData.hobbies }}</p>
      <p>Linguagens de programação: {{ userData.linguagens }}</p>
      <p>Biografia: {{ userData.biografia }}</p>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      userData: {},
      showUserData: false,
    };
  },
  methods: {
    submitForm() {
      
      const nome = document.getElementById("nome").value;
      const email = document.getElementById("email").value;
      const dataNascimento = document.getElementById("data-nascimento").value;
      const endereco = document.getElementById("endereco").value;
      const cidade = document.getElementById("cidade").value;
      const estado = document.getElementById("estado").value;
      const hobbies = document.getElementById("hobbies").value;
      const linguagens = document.getElementById("linguagens").value;
      const biografia = document.getElementById("biografia").value;

      
      this.userData = {
        nome,
        email,
        dataNascimento,
        endereco,
        cidade,
        estado,
        hobbies,
        linguagens,
        biografia,
      };

      this.showUserData = true;
    },
  },
};
</script>

<style scoped>
  label {
    display: block;
    margin-bottom: 10px;
    background: linear-gradient(
      90deg,
      rgb(50, 204, 165) 100%,
      rgb(58, 136, 90) 0%
    );
  }

  input,
  select,
  textarea {
    width: 100%;
    padding: 5px;
    margin-bottom: 15px;
    box-sizing: border-box;
    border: 1px solid #c28d8d;
    border-radius: 3px;
    
  }

  button[type="submit"] {
    background-color: #008CBA;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 3px;
    cursor: pointer;
  }

  button[type="submit"]:hover {
    background-color: #146861;
  }
</style>